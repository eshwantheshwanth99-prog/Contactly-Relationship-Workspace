#include "contact_core.hpp"
#include <iostream>
int main() {
    Contact a = {1, "Zara", "919000000001", "", ""};
    Contact b = {2, "Arun", "9000000002", "", ""};
    vector<Contact> contacts;
    contacts.push_back(a); contacts.push_back(b);
    int failures = 0;
    if (alphabeticalContacts(contacts)[0].name != "Arun") failures++;
    if (searchNames(contacts, "zAR").size() != 1) failures++;
    if (searchPhones(contacts, "+91 90000 00001").size() != 1) failures++;
    if (findContactIndex(contacts, 99) != -1) failures++;
    if (!checkContact(a).valid) failures++;
    a.name = " "; if (checkContact(a).valid) failures++;
    a = b; a.phone = "12abc"; if (checkContact(a).valid) failures++;
    a = b; a.email = "bad"; if (checkContact(a).valid) failures++;
    if (!phoneDigits("123").empty()) failures++;
    if (phoneDigits("01234567") != "01234567") failures++;
    vector<Contact> empty;
    if (!alphabeticalContacts(empty).empty()) failures++;
    if (!searchNames(contacts, " ").empty()) failures++;
    cout << "12 core checks; failures: " << failures << endl;
    return failures != 0;
}
