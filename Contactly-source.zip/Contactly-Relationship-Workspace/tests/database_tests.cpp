#include "database.hpp"
#include <iostream>
using namespace std;
int checks = 0;
int failures = 0;
void check(bool condition, string label) {
    checks++;
    if (condition) cout << "PASS: " << label << '\n';
    else { failures++; cout << "FAIL: " << label << '\n'; }
}
int main() {
    // CTest runs in the build folder. This dedicated file is test data only.
    DatabaseResult result = openDatabase("database-integration-test.db");
    check(result.success, "Connect to real SQLite database");
    if (!result.success) return 1;
    for (int i = 0; i < (int)result.records.size(); i++) deleteStoredContact(result.records[i].id);
    result = loadContacts();
    check(result.success && result.records.empty(), "Read empty records");
    Contact a = {0, "Zara", "+91 90000 00001", "zara@example.com", "City"};
    result = insertContact(a);
    check(result.success && result.id > 0, "Insert and generate permanent ID");
    long long first = result.id;
    check(!insertContact(a).success, "Database enforces duplicate phone rejection");
    Contact b = {0, "Arun", "9000000002", "", ""};
    result = insertContact(b);
    check(result.success && result.id != first, "Distinct IDs");
    long long second = result.id;
    b.id = second; b.phone = "919000000001";
    check(!updateStoredContact(b).success, "Duplicate update rejected");
    result = loadContacts();
    int index = findContactIndex(result.records, second);
    check(index != -1 && result.records[index].phone == "9000000002", "Failed update preserves original");
    a.id = first; a.name = "Zara Khan"; a.email = "";
    check(updateStoredContact(a).success, "Update existing contact");
    closeDatabase();
    result = openDatabase("database-integration-test.db");
    check(result.success && result.records.size() == 2, "Contacts survive connection restart");
    index = findContactIndex(result.records, first);
    check(index != -1 && result.records[index].name == "Zara Khan" && result.records[index].email.empty(), "Updated and cleared fields persist");
    check(deleteStoredContact(second).success, "Delete existing contact");
    check(!deleteStoredContact(second).success, "Missing delete ID");
    b.id = second;
    check(!updateStoredContact(b).success, "Missing update ID");
    check(!deleteStoredContact(0).success, "Invalid ID rejected");
    b.name = " ";
    check(!insertContact(b).success, "Backend independently validates input");
    Contact quoted = {0, "O'Neil; DROP TABLE contacts;--", "1234567", "", ""};
    result = insertContact(quoted);
    check(result.success, "Bound values safely store quotes and SQL-like text");
    long long quotedId = result.id;
    check(deleteStoredContact(quotedId).success && deleteStoredContact(first).success, "Clean up test contacts");
    closeDatabase();
    result = openDatabase("database-integration-test.db");
    check(result.success && result.records.empty(), "Deletions persist after restart");
    closeDatabase();
    check(!loadContacts().success, "Disconnected operations report error");
    check(!openDatabase(":memory:").success, "Require persistent database");
    cout << checks << " database checks; failures: " << failures << '\n';
    return failures != 0;
}
