const $ = id => document.getElementById(id);
let contacts = [], pendingDelete = null, generation = 0, view="all", groupFilter="", available=false;
async function api(path, data) {
  const response = await fetch(path, data ? {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Contact-Request':'1'},body:new URLSearchParams(data),signal:AbortSignal.timeout(10000)} : {signal:AbortSignal.timeout(10000)});
  const result = await response.json();
  if (!response.ok) { const error=new Error(result.error || 'Unable to complete request.'); error.status=response.status; throw error; }
  return result;
}
function notice(message, error=false) { $('notice').textContent=message; $('notice').className=error?'error':''; }
function element(tag, className, text) { const e=document.createElement(tag); e.className=className; e.textContent=text; return e; }
function phoneHelp() {
  const india=$('country').value==='IN';
  $('phoneHelp').textContent=india?'India: enter 10 digits. +91 is added automatically.':'Include + and the country code; 7–15 digits in total.';
  $('phone').placeholder=india?'e.g. 90000 00001':'e.g. +44 20 7946 0123';
}
$('country').onchange=()=>{$('formError').textContent='';phoneHelp();};
function openEditor(c) {
  $('contactForm').reset();$('formError').textContent='';
  $('contactId').value=c?c.id:'';
  for(const key of ['name','phone','email','address'])$(key).value=c?c[key]:'';
  const digits=c?c.phone.replace(/\D/g,''):'';
  $('country').value=!c || (digits.length===12 && digits.startsWith('91'))?'IN':'INT';
  if(c) $('phone').value=$('country').value==='IN'?(digits.length===12?digits.slice(2):digits):'+'+digits;
  phoneHelp();
  $('dialogTitle').textContent=c?'Edit contact':'New contact';
  $('editor').showModal();$('name').focus();
}
$('add').onclick=$('emptyAdd').onclick=()=>openEditor();
$('close').onclick=$('cancel').onclick=()=>$('editor').close();
$('contactForm').onsubmit=async e=>{
  e.preventDefault();$('save').disabled=true;$('formError').textContent='';
  const data=Object.fromEntries(['name','phone','email','address'].map(k=>[k,$(k).value]));
  data.country=$('country').value;
  const id=$('contactId').value;if(id)data.id=id;
  try{await api(id?'/api/update':'/api/add',data);$('editor').close();notice(id?'Contact updated.':'New contact saved.');await refresh();}
  catch(e){$('formError').textContent=e.message;}finally{$('save').disabled=false;}
};
$('cancelDelete').onclick=()=>$('deleteDialog').close();
$('confirmDelete').onclick=async()=>{
  $('confirmDelete').disabled=true;
  try{await api('/api/delete',{id:pendingDelete});$('deleteDialog').close();notice('Contact deleted.');await refresh();}
  catch(e){$('deleteError').textContent=e.message;}finally{$('confirmDelete').disabled=false;}
};
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
const due=c=>c.details?.followUp && c.details.followUp<=today();
const missing=c=>['email','address'].filter(k=>!c[k]);
function render(rows) {
 $('cards').replaceChildren();
 for(const c of rows){
  const d=c.details||{},card=element('article','card',''),top=element('div','card-top','');
  const star=element('button','star'+(d.favorite?' active':''),d.favorite?'★':'☆');
  star.setAttribute('aria-label',(d.favorite?'Unfavorite ':'Favorite ')+c.name);star.setAttribute('aria-pressed',String(!!d.favorite));
  star.onclick=async()=>{star.disabled=true;try{await saveDetails(c,{favorite:!d.favorite});await refresh();}catch(e){notice(e.message,true);star.disabled=false;}};
  top.append(element('div','avatar',c.name.split(/\s+/).slice(0,2).map(n=>Array.from(n)[0]).join('').toUpperCase()),star);
  card.append(top,element('h3','',c.name),element('span','tag',d.group||'Unsorted'));
  for(const [symbol,value] of [['↗','+'+c.phone],['@',c.email||'No email added'],['⌖',c.address||'No address added']]){
   const row=element('div','detail','');row.append(element('span','symbol',symbol),element('span','',value));card.append(row);
  }
  if(d.followUp)card.append(element('div','due',(due(c)?'◷ Follow-up due · ':'◷ Next hello · ')+d.followUp));
  if(view==='health' && missing(c).length)card.append(element('p','quality-note','Missing '+missing(c).join(' and ')));
  const actions=element('div','card-actions',''),details=element('button','','Connection'),edit=element('button','','Edit'),del=element('button','remove','Delete');
  details.setAttribute('aria-label','Connection details for '+c.name);details.onclick=()=>openDetails(c);
  edit.setAttribute('aria-label','Edit '+c.name);edit.onclick=()=>openEditor(c);
  del.setAttribute('aria-label','Delete '+c.name);del.onclick=()=>{pendingDelete=c.id;$('deleteText').textContent=c.name;$('deleteError').textContent='';$('deleteDialog').showModal();};
  actions.append(details,edit,del);card.append(actions);$('cards').append(card);
 }
 $('empty').hidden=rows.length>0;
 $('empty').querySelector('h2').textContent=contacts.length?'A little breathing room':'Your next connection starts here';
 $('empty').querySelector('p').textContent=contacts.length?'No contacts match this view. Try another circle or reset your filters.':'Add your first contact to build your personal address book.';
 $('emptyAdd').hidden=contacts.length>0;$('shown').textContent='Showing '+rows.length+' of '+contacts.length+' contacts';$('badge').textContent=rows.length;
}
function applyView(){
 const q=$('query').value.trim().toLocaleLowerCase(),digits=q.replace(/\D/g,'');
 let rows=contacts.filter(c=>{
  const d=c.details||{};
  return (!groupFilter||d.group===groupFilter)&&(view!=='favorites'||d.favorite)&&(view!=='due'||due(c))&&(view!=='health'||missing(c).length)&&(!q||[c.name,c.email,c.phone,c.address,d.notes||''].some(v=>v.toLocaleLowerCase().includes(q))||(digits.length>=3&&c.phone.includes(digits)));
 });
 const sort=$('sort').value;
 rows.sort((a,b)=>sort==='recent'?b.id-a.id:sort==='followUp'?(a.details?.followUp||'9999').localeCompare(b.details?.followUp||'9999')||a.name.localeCompare(b.name):a.name.localeCompare(b.name));
 $('viewTitle').textContent=groupFilter||({all:'All contacts',favorites:'Your favorites',due:'Follow-up queue',health:'Contact health'})[view];
 render(rows);
}
async function refresh(){
 const request=++generation;
 try{
  const all=await api('/api/contacts');if(request!==generation)return;
  contacts=all;available=true;$('total').textContent=$('sideCount').textContent=all.length;
  $('dueTotal').textContent=$('dueCount').textContent=all.filter(due).length;
  const completed=all.reduce((sum,c)=>sum+4-missing(c).length,0);
  $('quality').textContent=(all.length?Math.round(completed/(all.length*4)*100):0)+'%';
  const gaps=all.filter(c=>missing(c).length).length,groups=all.filter(c=>!c.details?.group).length;
  $('insightText').textContent=all.length?gaps+' contacts have missing details · '+groups+' haven’t found their circle yet. Completeness measures fields, not relationship strength.':'Add your first person, give them a circle, and plan your next hello.';
  $('connection').textContent=new URLSearchParams(location.search).get('demo')==='1'?'Demo · fictional contacts':'● Database connected';$('export').disabled=false;applyView();
 }catch(e){if(request===generation){available=false;$('export').disabled=true;notice('Could not refresh: '+e.message+'. Displayed contacts may be out of date.',true);$('connection').textContent='Offline · retry refresh';}}
}
function setView(next,group=''){view=next;groupFilter=group;document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('selected',group?b.dataset.group===group:b.dataset.view===view));applyView();}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view));
document.querySelectorAll('[data-group]').forEach(b=>b.onclick=()=>setView('all',b.dataset.group));
$('insightAction').onclick=()=>setView('health');
$('searchForm').onsubmit=e=>{e.preventDefault();applyView();};
$('query').oninput=applyView;$('sort').onchange=applyView;
$('reset').onclick=()=>{$('query').value='';$('sort').value='name';setView('all');notice('');refresh();};
$('gridView').onclick=()=>layout(false);$('listView').onclick=()=>layout(true);
function layout(compact){$('cards').classList.toggle('compact',compact);$('gridView').setAttribute('aria-pressed',String(!compact));$('listView').setAttribute('aria-pressed',String(compact));}
async function saveDetails(c,patch={}){
 const d={group:'',notes:'',followUp:'',lastContacted:'',favorite:false,...c.details,...patch};
 return api('/api/details',{id:c.id,group:d.group,notes:d.notes,followUp:d.followUp,lastContacted:d.lastContacted,favorite:d.favorite?'1':'0'});
}
function openDetails(c){$('detailsId').value=c.id;$('detailsName').textContent=c.name;const d=c.details||{};for(const k of ['group','notes','followUp','lastContacted'])$(k).value=d[k]||'';$('favorite').checked=!!d.favorite;$('detailsError').textContent='';$('detailsDialog').showModal();}
$('closeDetails').onclick=()=>$('detailsDialog').close();
$('markConnected').onclick=()=>{$('lastContacted').value=today();$('followUp').value='';notice('Save details to record today’s connection and clear the reminder.');};
$('detailsForm').onsubmit=async e=>{
 e.preventDefault();$('saveDetails').disabled=true;$('detailsError').textContent='';
 const c=contacts.find(c=>c.id===Number($('detailsId').value));
 try{if(!c)throw new Error('Contact no longer available. Refresh and retry.');await saveDetails(c,{...Object.fromEntries(['group','notes','followUp','lastContacted'].map(k=>[k,$(k).value])),favorite:$('favorite').checked});$('detailsDialog').close();notice('Connection details saved.');await refresh();}
 catch(e){$('detailsError').textContent=e.message;}finally{$('saveDetails').disabled=false;}
};
function csvCell(value){let text=String(value??'');if(/^[\s]*[=+@\-]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';}
$('export').onclick=()=>{
 if(!available){notice('Reconnect before exporting your contacts.',true);return;}
 const rows=[['Name','Phone','Email','Address','Circle','Favorite','Follow-up','Last connected','Notes'],...contacts.map(c=>[c.name,c.phone,c.email,c.address,c.details?.group,c.details?.favorite?'Yes':'No',c.details?.followUp,c.details?.lastContacted,c.details?.notes])];
 const blob=new Blob(['\uFEFF'+rows.map(r=>r.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='contactly-'+today()+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Exported all '+contacts.length+' contacts. Keep this file private.');
};
document.addEventListener('keydown',e=>{if(e.key==='/'&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!document.querySelector('dialog[open]')&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)){e.preventDefault();$('query').focus();}});
refresh();
