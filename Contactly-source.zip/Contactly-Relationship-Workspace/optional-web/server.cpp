// OPTIONAL WEB ADAPTER: networking/HTTP concepts beyond the syllabus.
// The required console program does not compile this file.
// All contact logic and database writes use the same current core functions.
#include "contact_core.hpp"
#include "database.hpp"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <csignal>
#include <cstdlib>
#include <charconv>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>

namespace {
struct Socket { int fd; ~Socket() { if (fd >= 0) close(fd); } };
std::string json(const std::string& value) {
    std::string out = "\"";
    const char* hex = "0123456789abcdef";
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
        else out += c;
    }
    return out + "\"";
}
std::string encode(const std::vector<Contact>& contacts) {
    std::string out = "[";
    for (const auto& c : contacts) {
        if (out.size() > 1) out += ',';
        out += "{\"id\":" + std::to_string(c.id) + ",\"name\":" + json(c.name) +
               ",\"phone\":" + json(c.phone) + ",\"email\":" + json(c.email) +
               ",\"address\":" + json(c.address) + ",\"details\":" + loadContactDetails(c.id) + "}";
    }
    return out + "]";
}
int hex(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    throw std::invalid_argument("Malformed URL encoding.");
}
std::string decode(const std::string& s) {
    std::string out;
    for (std::size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '+') out += ' ';
        else if (s[i] == '%') {
            if (i + 2 >= s.size()) throw std::invalid_argument("Malformed URL encoding.");
            const char ch = static_cast<char>(hex(s[i+1])*16 + hex(s[i+2]));
            if (!ch) throw std::invalid_argument("Null characters are not allowed.");
            out += ch; i += 2;
        } else out += s[i];
    }
    return out;
}
std::map<std::string,std::string> form(const std::string& body) {
    std::map<std::string,std::string> result;
    std::istringstream stream(body); std::string pair;
    while (std::getline(stream, pair, '&')) {
        const auto pos = pair.find('=');
        if (pos != std::string::npos) result[decode(pair.substr(0,pos))] = decode(pair.substr(pos+1));
    }
    return result;
}
std::int64_t number(const std::string& value) {
    std::int64_t n = 0;
    auto r = std::from_chars(value.data(), value.data()+value.size(), n);
    if (r.ec != std::errc{} || r.ptr != value.data()+value.size() || n < 0)
        throw std::invalid_argument("Invalid number.");
    return n;
}
void reply(int fd, int code, const std::string& body, const std::string& type="application/json") {
    const auto data = "HTTP/1.1 " + std::to_string(code) + " Response\r\nContent-Type: " + type +
        "; charset=utf-8\r\nContent-Length: " + std::to_string(body.size()) +
        "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n"
        "Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'\r\n\r\n" + body;
    std::size_t sent = 0;
    while (sent < data.size()) {
        const auto n = send(fd, data.data()+sent, data.size()-sent, 0);
        if (n <= 0) break;
        sent += static_cast<std::size_t>(n);
    }
}
void handle(int fd, const std::string& root, int port) {
    std::string request; char buffer[4096];
    auto readMore = [&] {
        const auto n = recv(fd, buffer, sizeof(buffer), 0);
        if (n <= 0) throw std::runtime_error("Incomplete request.");
        request.append(buffer, static_cast<std::size_t>(n));
        if (request.size() > 32768) throw std::invalid_argument("Request too large.");
    };
    while (request.find("\r\n\r\n") == std::string::npos) readMore();
    const auto end = request.find("\r\n\r\n");
    std::istringstream headers(request.substr(0,end));
    std::string method, target, version, line;
    headers >> method >> target >> version; std::getline(headers,line);
    std::map<std::string,std::string> h;
    while (std::getline(headers,line)) {
        const auto colon = line.find(':');
        if (colon != std::string::npos) h[lowercase(line.substr(0,colon))] = trimText(line.substr(colon+1));
    }
    const std::string host = "localhost:"+std::to_string(port), ip = "127.0.0.1:"+std::to_string(port);
    const char* configuredOrigin = std::getenv("PUBLIC_ORIGIN");
    const std::string publicOrigin = configuredOrigin ? configuredOrigin : "";
    const std::string publicHost = publicOrigin.substr(publicOrigin.find("://") == std::string::npos ? 0 : publicOrigin.find("://") + 3);
    if (h["host"] != host && h["host"] != ip && (publicOrigin.empty() || h["host"] != publicHost)) { reply(fd,403,"{\"error\":\"Invalid host\"}"); return; }
    const auto length = h.count("content-length") ? number(h["content-length"]) : 0;
    if (length > 16384 || h.count("transfer-encoding")) throw std::invalid_argument("Unsupported request body.");
    while (request.size()-end-4 < static_cast<std::size_t>(length)) readMore();
    const auto queryPos = target.find('?');
    const auto path = target.substr(0,queryPos);
    auto query = form(queryPos == std::string::npos ? "" : target.substr(queryPos+1));
    if (method == "GET" && path == "/api/contacts") {
        DatabaseResult loaded = loadContacts();
        if (!loaded.success) throw std::runtime_error(loaded.error);
        auto contacts = loaded.records;
        if (!trimText(query["q"]).empty()) contacts = query["by"] == "phone" ? searchPhones(contacts,query["q"]) : searchNames(contacts,query["q"]);
        if (query["by"] == "phone" && !trimText(query["q"]).empty() && phoneDigits(query["q"]).empty()) throw std::invalid_argument("Enter a valid complete phone number.");
        // Accept India's national form as well as the stored international form.
        if (query["by"] == "phone") {
            string digits = phoneDigits(query["q"]);
            if (digits.size() == 10 && trimText(query["q"])[0] != '+') {
                for (const Contact& match : searchPhones(loaded.records, "91" + digits)) contacts.push_back(match);
            }
        }
        if (query["sort"] == "name") contacts = alphabeticalContacts(contacts);
        reply(fd,200,encode(contacts)); return;
    }
    if (method == "POST" && (path == "/api/add" || path == "/api/update" || path == "/api/delete" || path == "/api/details")) {
        if (h["x-contact-request"] != "1" ||
            (h.count("origin") && h["origin"] != "http://"+host && h["origin"] != "http://"+ip && (publicOrigin.empty() || h["origin"] != publicOrigin))) {
            reply(fd,403,"{\"error\":\"Request origin rejected\"}"); return;
        }
        if (h["content-type"].find("application/x-www-form-urlencoded") != 0)
            throw std::invalid_argument("Expected form data.");
        auto fields = form(request.substr(end+4, static_cast<std::size_t>(length)));
        if (path == "/api/details") {
            const auto id=number(fields["id"]);
            const std::string group=fields["group"], notes=fields["notes"], due=fields["followUp"], last=fields["lastContacted"];
            if (group!="" && group!="Friends" && group!="Family" && group!="Work" && group!="Mentors") throw std::invalid_argument("Invalid group.");
            auto dateValid=[](const std::string& d) {
                if(d.empty()) return true;
                if(d.size()!=10 || d[4]!='-' || d[7]!='-') return false;
                for(std::size_t i=0;i<d.size();++i) if(i!=4 && i!=7 && (d[i]<'0'||d[i]>'9')) return false;
                int y=std::stoi(d.substr(0,4)),m=std::stoi(d.substr(5,2)),day=std::stoi(d.substr(8,2));
                if(y<1900||y>2200||m<1||m>12)return false;
                int days[]={31,28,31,30,31,30,31,31,30,31,30,31};
                if(y%4==0&&(y%100!=0||y%400==0))days[1]=29;
                return day>=1 && day<=days[m-1];
            };
            if(notes.size()>2000 || !dateValid(due) || !dateValid(last) || (fields["favorite"]!="0" && fields["favorite"]!="1")) throw std::invalid_argument("Invalid notes, date or favorite value.");
            std::string payload="{\"group\":"+json(group)+",\"notes\":"+json(notes)+",\"followUp\":"+json(due)+",\"lastContacted\":"+json(last)+",\"favorite\":"+(fields["favorite"]=="1"?"true":"false")+"}";
            auto result=saveContactDetails(id,payload);
            reply(fd,result.success?200:404,result.success?"{\"ok\":true}":"{\"error\":"+json(result.error)+"}");return;
        }
        Contact c{0,fields["name"],fields["phone"],fields["email"],fields["address"]};
        // The website defaults to India; the console keeps its general phone format.
        if (path != "/api/delete" && fields.count("country")) {
            string digits = phoneDigits(c.phone);
            if (fields["country"] == "IN") {
                if (digits.size() == 12 && digits.substr(0,2) == "91") digits = digits.substr(2);
                if (digits.size() != 10) throw std::invalid_argument("India: enter exactly 10 digits, optionally prefixed with +91.");
                c.phone = "91" + digits;
                // Avoid duplicating older Indian entries stored without their prefix.
                DatabaseResult saved = loadContacts();
                if (!saved.success) throw std::runtime_error(saved.error);
                for (const Contact& old : saved.records) {
                    if (std::to_string(old.id) != fields["id"] && old.phone == digits)
                        throw std::invalid_argument("A contact with that phone number already exists.");
                }
            } else if (fields["country"] == "INT") {
                if (digits.empty() || trimText(c.phone).empty() || trimText(c.phone)[0] != '+' || digits[0] == '0')
                    throw std::invalid_argument("Enter + followed by the country code and phone number (7–15 digits total).");
            } else throw std::invalid_argument("Choose a valid country option.");
        }
        if (path == "/api/add") { DatabaseResult result = insertContact(c); if (!result.success) throw std::runtime_error(result.error); reply(fd,200,"{\"id\":"+std::to_string(result.id)+"}"); }
        else {
            const auto id = number(fields["id"]);
            c.id = id;
            DatabaseResult result = path == "/api/update" ? updateStoredContact(c) : deleteStoredContact(id);
            if (!result.success) { reply(fd,result.error == "No contact with that ID." ? 404 : 400,"{\"error\":"+json(result.error)+"}"); return; }
            reply(fd,200,"{\"ok\":true}");
        }
        return;
    }
    if (method == "GET" && (path == "/" || path == "/app.js" || path == "/style.css")) {
        const auto file = path == "/" ? "/index.html" : path;
        std::ifstream input(root+file);
        if (!input) throw std::runtime_error("Web assets unavailable.");
        std::ostringstream body; body << input.rdbuf();
        reply(fd,200,body.str(),path == "/" ? "text/html" : path == "/app.js" ? "text/javascript" : "text/css"); return;
    }
    reply(fd,404,"{\"error\":\"Not found\"}");
}
}
int main(int argc, char** argv) {
    try {
        const std::string db = argc > 1 ? argv[1] : "contacts.db";
        const auto parsed = argc > 2 ? number(argv[2]) : 8080;
        if (parsed < 1024 || parsed > 65535) throw std::invalid_argument("Port must be 1024–65535.");
        const int port = static_cast<int>(parsed);
        const std::string root = argc > 3 ? argv[3] : "optional-web/web";
        if (!std::ifstream(root+"/index.html")) throw std::runtime_error("Run from the project folder or provide web asset path.");
        DatabaseResult opened = openDatabase(db);
        if (!opened.success) throw std::runtime_error(opened.error);
        std::signal(SIGPIPE,SIG_IGN);
        Socket server{socket(AF_INET,SOCK_STREAM,0)};
        if (server.fd < 0) throw std::runtime_error("Cannot create listening socket.");
        int reuse=1; setsockopt(server.fd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(reuse));
        sockaddr_in address{}; address.sin_family=AF_INET; address.sin_port=htons(port); address.sin_addr.s_addr=htonl(std::getenv("PUBLIC_ORIGIN") ? INADDR_ANY : INADDR_LOOPBACK);
        if (::bind(server.fd,reinterpret_cast<sockaddr*>(&address),sizeof(address)) != 0 || listen(server.fd,16) != 0)
            throw std::runtime_error("Cannot listen on localhost; port may be occupied or network access restricted.");
        std::cout << "Contact manager running: http://localhost:" << port << "\nDatabase: " << db << "\nPress Ctrl+C to stop.\n" << std::flush;
        while (true) {
            Socket client{accept(server.fd,nullptr,nullptr)};
            if (client.fd < 0) continue;
            timeval timeout{3,0};
            setsockopt(client.fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
            setsockopt(client.fd,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
            try { handle(client.fd,root,port); }
            catch (const std::exception& e) { reply(client.fd,400,"{\"error\":"+json(e.what())+"}"); }
        }
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
