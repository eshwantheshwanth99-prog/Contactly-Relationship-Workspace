"""Real HTTP integration checks against an isolated C++ server and disk DB."""
import json, pathlib, socket, sqlite3, subprocess, tempfile, time
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError
root=pathlib.Path(__file__).resolve().parents[1]
checks=0
with tempfile.TemporaryDirectory() as tmp:
    with socket.socket() as s:
        s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
    db=pathlib.Path(tmp)/'web.db'
    process=subprocess.Popen([str(root/'build/contact_web'),str(db),str(port),str(root/'optional-web/web')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    def call(path,data=None,headers=None):
        h={'X-Contact-Request':'1'} if headers is None else headers
        req=Request(f'http://localhost:{port}'+path,data=urlencode(data).encode() if data is not None else None,headers=h)
        try:
            with urlopen(req,timeout=6) as r:return r.status,r.read().decode()
        except HTTPError as e:return e.code,e.read().decode()
    def check(ok,label):
        global checks
        assert ok,label
        checks+=1;print('PASS:',label)
    try:
        for _ in range(50):
            try:call('/');break
            except OSError:time.sleep(.05)
        check('Contactly' in call('/')[1],'HTML served')
        check('refresh' in call('/app.js')[1],'JavaScript served')
        check('.cards' in call('/style.css')[1],'Styles served')
        check(json.loads(call('/api/contacts')[1])==[],'Empty database')
        a={'name':'Zara','phone':'+91 90000 00001','email':'zara@example.com','address':'City'}
        check(call('/api/add',a)[0]==200,'Add through C++ HTTP adapter')
        check(call('/api/add',a)[0]==400,'Duplicate phone rejected')
        check(call('/api/add',dict(a,phone='bad'))[0]==400,'Invalid phone rejected')
        check(call('/api/add',dict(a,phone='9000000002',name='Arun'))[0]==200,'Second contact')
        rows=json.loads(call('/api/contacts?sort=name')[1])
        check([c['name'] for c in rows]==['Arun','Zara'],'C++ alphabetical sorting')
        check(len(json.loads(call('/api/contacts?q=zAr&by=name')[1]))==1,'C++ name searching')
        check(len(json.loads(call('/api/contacts?q=919000000001&by=phone')[1]))==1,'C++ phone searching')
        check(call('/api/update',dict(a,id=1,name='Zara Khan',email=''))[0]==200,'Update')
        with sqlite3.connect(db) as connection:
            check(connection.execute('SELECT name,email FROM contacts WHERE id=1').fetchone()==('Zara Khan',''),'Independent SQL verifies update')
        check(call('/api/delete',{'id':999})[0]==404,'Missing ID')
        check(call('/api/delete',{'id':2},headers={})[0]==403,'Write requires custom request header')
        check(call('/api/delete',{'id':2},headers={'X-Contact-Request':'1','Origin':'https://example.com'})[0]==403,'Foreign origin rejected')
        check(call('/api/delete',{'id':2})[0]==200,'Delete')
        check(call('/contacts.db')[0]==404,'Database file not exposed')
        check(call('/api/contacts',headers={'Host':'example.com'})[0]==403,'Foreign Host rejected')
        process.terminate();process.wait(timeout=5)
        process=subprocess.Popen([str(root/'build/contact_web'),str(db),str(port),str(root/'optional-web/web')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        for _ in range(50):
            try:rows=json.loads(call('/api/contacts')[1]);break
            except OSError:time.sleep(.05)
        check(len(rows)==1 and rows[0]['name']=='Zara Khan','HTTP changes persist across server restart')
        check(call('/api/add',dict(a,country='IN',phone='1234567'))[0]==400,'India rejects short number')
        check(call('/api/add',dict(a,country='IN',phone='9000000001'))[0]==400,'India duplicate rejected')
        check(call('/api/add',dict(a,country='IN',phone='9000000003'))[0]==200,'India number accepted')
        check(any(c['phone']=='919000000003' for c in json.loads(call('/api/contacts')[1])),'India prefix stored')
        check(call('/api/add',dict(a,country='INT',phone='442079460123'))[0]==400,'International requires plus')
        check(call('/api/add',dict(a,country='INT',phone='+44 20 7946 0123'))[0]==200,'International accepted')
        check(len(json.loads(call('/api/contacts?q=9000000003&by=phone')[1]))==1,'Indian national search finds prefixed record')
        check(call('/api/contacts?q=bad&by=phone')[0]==400,'Invalid phone search returns validation error')
        check(json.loads(call('/api/contacts')[1])!=[],'Valid request works after invalid search')
        details={'id':1,'group':'Mentors','notes':'Discuss next project <script>not executable</script>','followUp':'2026-10-05','lastContacted':'2026-10-01','favorite':'1'}
        check(call('/api/details',details)[0]==200,'Save relationship metadata')
        row=next(c for c in json.loads(call('/api/contacts')[1]) if c['id']==1)
        check(row['details']['favorite'] and row['details']['group']=='Mentors','Read persistent metadata')
        check(call('/api/details',dict(details,followUp='2026-02-30'))[0]==400,'Reject impossible calendar date')
        check(call('/api/details',dict(details,group='Unknown'))[0]==400,'Reject invalid circle')
        check(call('/api/details',dict(details,notes='x'*2001))[0]==400,'Bound note size')
        check(call('/api/details',dict(details,id=99999))[0]==404,'Reject orphan metadata')
        check(call('/api/details',details,headers={'X-Contact-Request':'1','Origin':'https://example.com'})[0]==403,'Metadata rejects foreign origins')
        process.terminate();process.wait(timeout=5)
        process=subprocess.Popen([str(root/'build/contact_web'),str(db),str(port),str(root/'optional-web/web')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        for _ in range(50):
            try:rows=json.loads(call('/api/contacts')[1]);break
            except OSError:time.sleep(.05)
        check(next(c for c in rows if c['id']==1)['details']['notes']==details['notes'],'Metadata survives server restart')
        check(call('/api/delete',{'id':1})[0]==200,'Delete contact with metadata')
        with sqlite3.connect(db) as connection:
            check(connection.execute('SELECT count(*) FROM contact_details WHERE id=1').fetchone()[0]==0,'Cascade cleans up relationship details')
        print(f'{checks} web checks passed.')
    finally:
        process.terminate();process.wait(timeout=5)
