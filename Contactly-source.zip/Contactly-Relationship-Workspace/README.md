# Contactly — a local relationship workspace

A first-year C++ and SQLite contact-management project, extended with a responsive web interface, saved circles, favorites, relationship notes, follow-up planning and explainable contact-health insights.

## What is new
See [the upgrade report](docs/UPGRADE_REPORT.md) for the review, implemented features, test evidence and limitations. The original console application remains available; the web adapter is separate.

- Add and edit contacts using the shared C++ validation rules.
- Organize people into circles and keep favorites close.
- Save a next follow-up and last-connected date; review due contacts.
- Store useful context in local notes.
- Search across details and notes; switch between cards and a compact view.
- Inspect missing fields and export contacts as a CSV file.

The app does not send messages or notifications. Contact-health scores describe field completeness, not the quality of a relationship.

## Quick start on macOS
Open START-WEBSITE.command from the project folder. Keep that folder and its terminal open while using the app. The launcher compiles the C++ server and opens localhost:8080.

Manual build:
```sh
mkdir -p build
c++ -std=c++17 -Wall -Wextra -Wpedantic -Iinclude optional-web/server.cpp src/contact_core.cpp src/database.cpp -lsqlite3 -o build/contact_web
./build/contact_web contacts.db 8082 optional-web/web
```
Then open http://localhost:8082. SQLite creates a persistent local database if none exists. Your existing contact rows are preserved; relationship metadata uses an additional table.

Verify the loaded assets with:
```sh
python3 scripts/check_assets.py http://localhost:8082
```

## Original project documentation
The details below describe the original syllabus-focused implementation and deployment notes. The upgrade report above is authoritative for the newly added optional web features.

# Group 11 — Contact Management System

A menu-driven C++ contact manager with permanent SQLite storage. The original project requirements take priority; syllabus-level code is used for contact operations, with a separate database connector for the required extra concepts.

## Run on this Mac

Double-click `run.command`, or open Terminal in this folder and enter:

```sh
./run.command
```

The launcher compiles and starts the console application. The C++ compiler and SQLite development library are available on the Mac used for verification. **Contacts are saved immediately to `contacts.db` in the project folder.** Exit and restart with the same database file to retrieve them. Do not delete this file if you want to retain your contacts.

## Open the Contactly website

Run `./start-web.command`, then open **http://localhost:8080**. The original Contactly design is restored with working add, display, search, sort, edit and delete controls. The launcher builds the optional C++17 web adapter on macOS/Linux. Leave it running; Ctrl+C stops the server.

The website and console use the same project `contacts.db` and the same C++ core/database functions. The website adapter and HTML/CSS/JavaScript are isolated in `optional-web/`. Networking and HTTP are additional concepts needed only for this optional website; the required console target remains C++11 with syllabus-focused contact logic. The adapter binds only to the local computer and is intended for a single-user classroom demo, not public hosting.

`run.command` still launches the console application. For the website's 20 isolated HTTP integration checks, run `python3 optional-web/web_test.py` after building. Python is used only for that test script, not as the website backend.

## Build and test

Requirements: C++11 or newer compiler, SQLite3 headers/library, and optionally CMake 3.16+.

```sh
cmake -S . -B build
cmake --build build
./build/contact_manager
ctest --test-dir build --output-on-failure
```

Run these commands from the project directory. When the executable is launched directly, `contacts.db` is in the current working directory. With the launcher, it is always in the project directory. A Windows multi-configuration build may place the executable in `build/Debug`. This release was tested on macOS ARM64.

Without CMake:

```sh
c++ -std=c++11 -Wall -Wextra -Wpedantic -Iinclude src/main.cpp src/menu.cpp src/contact_core.cpp src/database.cpp -lsqlite3 -o contact_manager
./contact_manager
```

## Menu

1. **Add contact:** required name and phone, optional email/address, database-generated ID.
2. **Display all contacts:** reads the database and displays all saved records in ID order.
3. **Search:** partial, case-insensitive name search or complete normalized phone search.
4. **Update:** select an ID, leave a field blank to keep it, or enter `-` to clear email/address.
5. **Delete:** select an ID and type `yes` to confirm; other responses cancel.
6. **Sort alphabetically:** creates an alphabetical view using C++ selection sort.
7. **Exit:** closes the database; all successful changes remain saved.

The menu reloads records from the database before each operation. A vector is used for processing, not as the only storage. Invalid writes leave the previous record unchanged. Failed reads cancel the operation instead of silently using stale data.

## Input rules

- Names: 1–100 bytes after trimming. Different contacts may have the same name.
- Phones: 7–15 digits; optional spaces, hyphens, parentheses and one leading `+` are removed. Leading zeroes are preserved. Duplicate normalized numbers are rejected both in the menu and by a database UNIQUE constraint. Country codes are not inferred.
- Email: optional, maximum 254 bytes, basic format check only.
- Address: optional, maximum 300 bytes.
- Control characters are rejected. IDs must be positive and within the supported numeric range.
- Name case folding is ASCII-based, not language-aware Unicode collation.

Empty lists, missing IDs, duplicate numbers, malformed input, overflowing numeric input and incomplete input are handled. Database locks wait up to three seconds before a clear error is reported. Corrupt or inaccessible databases cause a startup error. The application never falls back to temporary-only storage.

## How C++ and the database work together

`menu.cpp` calls ordinary database functions declared in `database.hpp`. `database.cpp` connects through SQLite's C API, executes prepared SQL statements, and returns a `DatabaseResult` structure containing success, an error message, an ID or contact rows.

SQLite is a real disk-backed SQL database. The requirements say a database “such as MySQL or MongoDB”; SQLite is used as another SQL database option. No separate server or credentials are needed.

The connector creates this table automatically:

```sql
CREATE TABLE contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT CHECK(id BETWEEN 1 AND 2147483647),
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 100),
    phone TEXT NOT NULL UNIQUE
        CHECK(length(phone) BETWEEN 7 AND 15 AND phone NOT GLOB '*[^0-9]*'),
    email TEXT NOT NULL DEFAULT '' CHECK(length(email) <= 254),
    address TEXT NOT NULL DEFAULT '' CHECK(length(address) <= 300)
);
```

Bound parameters keep user text separate from SQL. Each modifying statement is atomic and commits before success is reported. Older compatible contacts tables from the earlier project can be read without deleting their data; this is not a general schema migration system.

## Files to study

- `include/contact_core.hpp`: Contact and ContactCheck structures and ordinary function declarations.
- `src/contact_core.cpp`: string validation, linear searching and selection sort.
- `src/menu.cpp`: input/output, menu and contact operations.
- `src/main.cpp`: small entry point.
- `include/database.hpp`: structure-based connector interface.
- `src/database.cpp`: the isolated database API/SQL exception to the syllabus.
- `tests/core_tests.cpp`: 12 simple algorithm/validation checks.
- `tests/database_tests.cpp`: 20 real-database checks; uses only the connector functions, not raw SQLite pointers.
- `docs/REQUIREMENTS_AND_DEMO.md`: every requirement mapped to evidence, demonstration and contribution template.
- `docs/SYLLABUS_AUDIT.md`: syllabus mapping and exact additional concepts.
- `docs/TEST_RESULTS.txt`: current validation results.

The C++ tests can be rerun with CTest. The database test operates only on `database-integration-test.db` in the build directory and clears its own test contacts. It does not touch the application's `contacts.db`.

Website phone entry defaults to India (+91): enter 10 national digits, optionally with +91. Other country accepts an explicit + and the full international number (7–15 digits); this checks format, not country-specific numbering plans. Website phone search accepts either a 10-digit Indian national number or the full stored international number. Existing contacts are not migrated automatically.
