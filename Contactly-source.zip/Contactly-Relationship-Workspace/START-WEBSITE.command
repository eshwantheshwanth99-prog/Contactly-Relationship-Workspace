#!/bin/sh
# Build locally so the executable matches this Mac's processor.
cd "$(dirname "$0")" || exit 1
if ! xcrun --find clang++ >/dev/null 2>&1; then
  echo "Install Apple's Command Line Tools first: xcode-select --install"
  echo "After installation finishes, open this file again."
  read -r answer
  exit 1
fi
if curl -s --max-time 1 http://localhost:8080/ >/dev/null 2>&1; then
  echo "Port 8080 is already in use. Close the existing server before starting this project."
  read -r answer
  exit 1
fi
mkdir -p build
if ! c++ -std=c++17 -Wall -Wextra -Wpedantic -Iinclude optional-web/server.cpp src/contact_core.cpp src/database.cpp -lsqlite3 -o build/contact_web; then
  echo "Build failed. Keep this window open and review the error above."
  read -r answer
  exit 1
fi
unset PUBLIC_ORIGIN
./build/contact_web contacts.db 8080 optional-web/web &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null' EXIT
trap 'exit 0' INT TERM
attempt=0
while [ "$attempt" -lt 20 ]; do
  if ! kill -0 "$server_pid" 2>/dev/null; then
    echo "Server could not start. Review the error above."
    read -r answer
    exit 1
  fi
  if curl -fsS --max-time 1 http://localhost:8080/api/contacts >/dev/null 2>&1; then
    open http://localhost:8080/
    echo "Keep this Terminal window open while presenting. Press Control+C to stop."
    wait "$server_pid"
    exit $?
  fi
  sleep 1
  attempt=$((attempt + 1))
done
echo "Server did not become ready. Try again after checking the messages above."
read -r answer
exit 1
