"""Read-only smoke check: verify HTML, CSS, JavaScript and contact API."""
import json,sys
from urllib.request import urlopen
base=sys.argv[1] if len(sys.argv)>1 else 'http://localhost:8080'
for path,kind in [('/','text/html'),('/style.css','text/css'),('/app.js','text/javascript'),('/api/contacts','application/json')]:
    with urlopen(base+path,timeout=10) as response:
        content=response.read()
        assert response.status==200 and kind in response.headers['Content-Type'],path
        if path=='/api/contacts': assert isinstance(json.loads(content),list)
        else: assert len(content)>100,path
        print('PASS',path,kind)
