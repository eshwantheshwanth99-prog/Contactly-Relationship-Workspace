#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
c++ -std=c++17 -Wall -Wextra -Wpedantic -Iinclude optional-web/server.cpp src/contact_core.cpp src/database.cpp -lsqlite3 -o build/contact_web
exec ./build/contact_web contacts.db 8080 optional-web/web
