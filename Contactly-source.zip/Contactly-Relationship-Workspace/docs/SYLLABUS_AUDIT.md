# Syllabus alignment and approved database exception

On 2 October 2026, the user instructed that the original project requirements take first priority and authorized database connectivity. This release restores permanent storage while retaining the simple contact logic from the syllabus revision.

## Within the supplied syllabus

| Code | Concepts |
|---|---|
| main.cpp | Program structure, return values and function calls (Modules I–II) |
| menu.cpp | Streams, variables, ordinary type conversion, if/else, switch, loops, functions (I–II); strings (V); structures (VI); vector indexing (X) |
| contact_core.cpp | String traversal, comparison and built-in methods (V); structures (VI); loops/functions for linear search and selection sort (II); vectors (X); complexity (VII) |
| contact_core.hpp | Structures including one structure inside another, strings, vectors and declarations (II, V, VI, X) |
| database.hpp | Ordinary functions and a result structure containing a vector (II, VI, X) |
| C++ test files | Functions, conditions, structures, strings and vectors; the database tests call the simple connector interface |

No custom classes, constructors/destructors, lambdas, exception handling, generic function templates, move semantics, filesystem library, advanced number parsers or socket programming are present in the required console source under src/. `long long` is a basic integer type. `(int)` is an ordinary type conversion. `string::npos` is the standard unsuccessful-search result. String and vector are standard-library types explicitly allowed by the syllabus. The build system and launcher are supporting tools, not additional C++ application concepts.

## Only necessary material beyond the syllabus

`src/database.cpp` contains:

- SQLite library calls and SQL: CREATE TABLE, INSERT, SELECT, UPDATE and DELETE.
- SQLite connection/statement pointers, address arguments and a text-pointer conversion required by the C API.
- Prepared statements and parameter binding.
- Explicit statement finalization and connection closure.
- Database error codes, unique constraints and a lock timeout.

These are openly identified as the approved exception, not claimed to be covered by the syllabus. The rest of the program receives plain structures and calls normal functions. The connector itself avoids custom classes, exceptions and lambdas.

## DSA explanation

- **Structure:** Contact keeps ID, name, phone, email and address together.
- **String:** phones are identifiers, not arithmetic values, so leading zeroes are preserved.
- **Vector:** dynamically holds database rows for traversal, display, searching and sorting.
- **Linear name search:** inspect every contact for a lowercase substring. O(n) for bounded field lengths; substring comparison also depends on text length.
- **Linear phone/ID/duplicate search:** O(n) with bounded field lengths.
- **Selection sort:** nested loops select the smallest remaining lowercase name, with ID as a tie breaker. O(n²) comparisons. It sorts a display copy rather than changing the database's storage order.
- **Memory:** O(n) contact records. Vectors are passed by value for simple, reference-free interfaces; copying adds O(n) time/space where used. This is a teaching tradeoff suitable for a small contact list.
- **Persistence:** the database is the permanent source of truth; the vector is refreshed before operations. SQL writes must succeed before the program reports success.

Stacks, queues and 2D arrays are not added unnecessarily. They are listed across the course but are not demanded by this group's contact-management feature list.

This is a local, single-user teaching application. It does not provide multi-user conflict resolution or general database schema migration.

## Optional website restored at user request

The separate optional-web/ folder contains the original Contactly frontend and an HTTP adapter. The adapter uses networking, pointer casts, resource cleanup, exceptions and other C++17 features beyond the syllabus. These are not part of the console coursework target. It delegates validation, searching, selection sorting and all database changes to the same current core and connector; it does not restore the old class-based contact manager. The website is functional, not a recorded walkthrough.
