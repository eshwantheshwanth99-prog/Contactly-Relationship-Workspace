# Requirements coverage and demonstration

## Complete software checklist

| Supplied requirement | Implementation |
|---|---|
| Develop using C++; backend focus | All application logic and database connection are C++ |
| Clear menu-driven application | Seven main options and a name/phone search submenu |
| Use functions; keep main small | Separate files/functions; main only starts the application |
| Structures for related attributes | Contact, ContactCheck and DatabaseResult |
| At least one appropriate STL container | vector<Contact> |
| Searching | Explicit C++ linear scans for name, phone, ID and duplicate checks |
| Sorting | Explicit nested-loop selection sort, alphabetical display |
| Validation and graceful invalid operations | Empty/invalid fields, duplicate phones, missing IDs, invalid/overflowing choices, EOF |
| Readable and meaningfully commented | Explicit types, ordinary loops, separated validation/menu/connector |
| Add contact | insertContact and parameterized INSERT |
| Delete contact | Confirmation followed by deleteStoredContact and DELETE |
| Search by name | searchNames, case-insensitive ASCII substring search |
| Search by phone | searchPhones, normalized full-number match |
| Update details | updateStoredContact and UPDATE; optional-field clearing |
| Display all | loadContacts and SELECT |
| Alphabetical order | alphabeticalContacts |
| Connect C++ backend to a database | SQLite C API in database.cpp |
| Store and retrieve permanently | contacts.db survives application exits and restarts |
| Relevant database operations | INSERT, SELECT, UPDATE, DELETE; searches operate on freshly retrieved rows |
| Database errors | Explicit return status for connection, read/write, lock and constraint failures |
| Demonstrate connection and storage/retrieval | Startup prints connection/count; restart demonstration below |
| Optional frontend | Console plus optional working Contactly website supplied; website code is separate |
| DSA explanation | SYLLABUS_AUDIT.md and talking points below |
| Edge-case demonstration | Empty records, duplicates, invalid IDs and invalid input in the script below |
| Documentation and team contribution | This guide and honest contribution template below |

The implementation and preparation materials are complete. The students still need to conduct the live demonstration, explain the work and fill in their actual team contributions.

## Demonstration (6–8 minutes)

Use fictional contacts. To avoid changing personal contacts, start the compiled application from a new demo directory; its contacts.db will be separate. From the project folder:

```sh
mkdir -p demo
cd demo
../build/contact_manager
```

If demo/contacts.db already contains prior demo data, use another new directory. Do not delete existing personal data just to obtain an empty demonstration.

1. Explain: the program stores and manages personal contacts. Point out the successful database connection and loaded-contact count.
2. Choose 2 on a fresh database. Show the empty-list message (edge case one).
3. Add Zara, phone `9000000001`, email `zara@example.com`, address `Hyderabad`. Note the generated ID.
4. Add Arun, phone `9000000002`, and blank optional fields.
5. Choose 2. Explain that SELECT retrieves records into a vector of Contact structures.
6. Search by name `zAR`; explain lowercase conversion and linear substring search.
7. Search by phone `90000-00002`; explain normalization and exact matching.
8. Choose 6. Show Arun before Zara. Explain the outer loop, inner loop, smallest index and swap in selection sort.
9. Attempt another contact with `9000000001`. Show duplicate rejection (edge case two). Explain both the C++ duplicate scan and database UNIQUE constraint.
10. Update Zara using her actual ID. Change name to Zara Khan, keep phone blank, enter `-` to clear email, and set a new address. Display the result.
11. Try to update ID 999999. Show a missing-ID message. Try a letter at the main menu and show recovery.
12. Delete Arun by his ID. First cancel, then repeat and type yes. Display the remaining contact.
13. Exit with 7. Run `../build/contact_manager` again from the same demo directory. Zara Khan and the changed fields remain; Arun stays deleted. This proves database persistence across application processes.
14. Show database.cpp: connect, prepare, bind, execute, finalize, close. Explain why this connector is the necessary exception beyond the syllabus.
15. Show the test report. Run CTest from the project directory if time permits.

Optional independent database evidence if sqlite3 CLI is installed:

```sh
sqlite3 contacts.db 'SELECT id,name,phone,email,address FROM contacts ORDER BY id;'
```

Run that in the directory holding the demonstrated database. Do not claim the UI alone is a database: point to the SQL connector and the file that survives restart.

## Questions to prepare for

**Why a vector as well as a database?** The vector supports the taught traversal/search/sort operations; SQLite supplies permanent storage.

**Why store phone as a string?** It may start with zero and is not used for arithmetic.

**Are identical names allowed?** Yes; the normalized phone must be unique. IDs identify records when names are shared.

**What if a write fails?** No success is reported. SQLite executes a single modifying statement atomically, preserving the previous row on failure.

**Why not use classes or exceptions?** Plain functions, result structures and conditions keep the application close to the supplied syllabus.

**Why SQLite?** It is a persistent SQL database usable directly from C++; the requirement lists MySQL/MongoDB as examples. It avoids separate database-server setup.

**Is every line within the syllabus?** No. The small SQLite connector uses the approved extra database API and pointer concepts. The main contact logic stays within the course topics.

## Team contribution record

Fill this truthfully after review and rehearsal. Member identities and actual contributions were not supplied.

| Member name | Actual contribution | Function or evidence explained |
|---|---|---|
| To be filled | To be filled | To be filled |
| To be filled | To be filled | To be filled |
| To be filled | To be filled | To be filled |
| To be filled | To be filled | To be filled |
