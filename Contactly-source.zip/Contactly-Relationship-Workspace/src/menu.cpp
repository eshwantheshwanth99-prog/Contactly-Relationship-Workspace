#include "contact_core.hpp"
#include "database.hpp"
#include <iostream>
using namespace std;

// A fresh vector is loaded from the database before every menu operation.
vector<Contact> contacts;
bool inputEnded = false;

string readLine(string prompt) {
    cout << prompt;
    string text;
    if (!getline(cin, text)) inputEnded = true;
    return trimText(text);
}
// Read digits with a loop instead of exceptions or advanced parsing functions.
long long readNumber(string prompt) {
    string text = readLine(prompt);
    if (inputEnded || text.empty()) return -1;
    long long value = 0;
    for (int i = 0; i < (int)text.length(); i++) {
        if (text[i] < '0' || text[i] > '9') return -1;
        int digit = text[i] - '0';
        if (value > (2147483647 - digit) / 10) return -1;
        value = value * 10 + digit;
    }
    return value;
}
void displayContact(Contact contact) {
    cout << "\nID: " << contact.id << "\nName: " << contact.name;
    cout << "\nPhone: " << contact.phone << "\nEmail: ";
    if (contact.email.empty()) cout << "(none)"; else cout << contact.email;
    cout << "\nAddress: ";
    if (contact.address.empty()) cout << "(none)"; else cout << contact.address;
    cout << '\n';
}
void displayContacts(vector<Contact> records) {
    if (records.empty()) { cout << "No contacts found.\n"; return; }
    for (int i = 0; i < (int)records.size(); i++) displayContact(records[i]);
    cout << "\nTotal: " << records.size() << " contact(s).\n";
}
bool duplicatePhone(string phone, long long excludedId) {
    for (int i = 0; i < (int)contacts.size(); i++) {
        if (contacts[i].phone == phone && contacts[i].id != excludedId) return true;
    }
    return false;
}
void addContact() {
    Contact contact;
    contact.id = 0; // SQLite generates the permanent ID.
    contact.name = readLine("Name (required): "); if (inputEnded) return;
    contact.phone = readLine("Phone (7-15 digits): "); if (inputEnded) return;
    contact.email = readLine("Email (optional): "); if (inputEnded) return;
    contact.address = readLine("Address (optional): "); if (inputEnded) return;
    ContactCheck result = checkContact(contact);
    if (!result.valid) { cout << "Error: " << result.error << '\n'; return; }
    if (duplicatePhone(result.contact.phone, 0)) { cout << "A contact with that phone number already exists.\n"; return; }
    DatabaseResult saved = insertContact(result.contact);
    if (!saved.success) { cout << saved.error << '\n'; return; }
    cout << "Contact saved to database. ID: " << saved.id << '\n';
}
void searchContacts() {
    long long choice = readNumber("Search by 1. Name  2. Phone: ");
    if (inputEnded) return;
    if (choice == 1) {
        string query = readLine("Name or part of name: "); if (inputEnded) return;
        if (query.empty()) { cout << "Name search cannot be empty.\n"; return; }
        displayContacts(searchNames(contacts, query));
    } else if (choice == 2) {
        string query = readLine("Full phone number: "); if (inputEnded) return;
        if (phoneDigits(query).empty()) { cout << "Invalid phone: enter 7 to 15 digits with optional formatting.\n"; return; }
        displayContacts(searchPhones(contacts, query));
    } else cout << "Search choice must be 1 or 2.\n";
}
void updateContact() {
    long long id = readNumber("Contact ID to update: "); if (inputEnded) return;
    if (id <= 0) { cout << "ID must be a positive whole number.\n"; return; }
    int index = findContactIndex(contacts, id);
    if (index == -1) { cout << "No contact with that ID.\n"; return; }
    displayContact(contacts[index]);
    Contact edited = contacts[index];
    cout << "Leave blank to keep a field. Enter - to clear email or address.\n";
    string name = readLine("New name: "); if (inputEnded) return;
    string phone = readLine("New phone: "); if (inputEnded) return;
    string email = readLine("New email: "); if (inputEnded) return;
    string address = readLine("New address: "); if (inputEnded) return;
    if (!name.empty()) edited.name = name;
    if (!phone.empty()) edited.phone = phone;
    if (email == "-") edited.email = "";
    else if (!email.empty()) edited.email = email;
    if (address == "-") edited.address = "";
    else if (!address.empty()) edited.address = address;
    ContactCheck result = checkContact(edited);
    if (!result.valid) { cout << "Error: " << result.error << '\n'; return; }
    if (duplicatePhone(result.contact.phone, id)) { cout << "A contact with that phone number already exists.\n"; return; }
    DatabaseResult saved = updateStoredContact(result.contact);
    if (!saved.success) { cout << saved.error << '\n'; return; }
    cout << "Contact updated in database.\n";
}
void deleteContact() {
    long long id = readNumber("Contact ID to delete: "); if (inputEnded) return;
    if (id <= 0) { cout << "ID must be a positive whole number.\n"; return; }
    int index = findContactIndex(contacts, id);
    if (index == -1) { cout << "No contact with that ID.\n"; return; }
    displayContact(contacts[index]);
    string answer = lowercase(readLine("Type yes to delete this contact: "));
    if (inputEnded) return;
    if (answer != "yes") { cout << "Deletion cancelled.\n"; return; }
    DatabaseResult saved = deleteStoredContact(id);
    if (!saved.success) { cout << saved.error << '\n'; return; }
    cout << "Contact deleted from database.\n";
}
int runMenu() {
    DatabaseResult opened = openDatabase("contacts.db");
    if (!opened.success) {
        cout << "Startup failed: " << opened.error << '\n';
        cout << "Check the database file, its directory permissions and available disk space.\n";
        return 1;
    }
    cout << "Database connected: contacts.db (in the current working directory).\n";
    cout << "Loaded " << opened.records.size() << " saved contact(s).\n";
    cout << "Every successful change is saved immediately.\n";
    while (!inputEnded) {
        cout << "\n=== CONTACT MANAGEMENT SYSTEM | GROUP 11 ===\n";
        cout << "1. Add contact\n2. Display all contacts\n3. Search contacts\n";
        cout << "4. Update contact\n5. Delete contact\n6. Sort alphabetically\n7. Exit\n";
        long long choice = readNumber("Choose (1-7): ");
        if (inputEnded) break;
        if (choice == 7) {
            closeDatabase();
            cout << "Goodbye. All successful changes are saved.\n";
            return 0;
        }
        if (choice >= 1 && choice <= 6) {
            DatabaseResult loaded = loadContacts();
            if (!loaded.success) {
                cout << loaded.error << "\nOperation cancelled. Please try again.\n";
                continue;
            }
            contacts = loaded.records;
        }
        switch (choice) {
            case 1: addContact(); break;
            case 2: displayContacts(contacts); break;
            case 3: searchContacts(); break;
            case 4: updateContact(); break;
            case 5: deleteContact(); break;
            case 6: displayContacts(alphabeticalContacts(contacts)); break;
            default: cout << "Invalid menu choice. Enter a whole number from 1 to 7.\n";
        }
    }
    closeDatabase();
    cout << "\nInput ended. All successful changes are saved.\n";
    return 0;
}
