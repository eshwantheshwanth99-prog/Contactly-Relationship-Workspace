#include "database.hpp"
#include <sqlite3.h>

// REQUIRED EXCEPTION TO THE SYLLABUS:
// SQLite's C API needs pointers, addresses and explicit resource cleanup.
// SQL and these API calls are confined to this database connector.
// No custom classes, exceptions, lambdas or generic templates are used.
static sqlite3* connection = 0;

DatabaseResult makeResult(bool success, string error) {
    DatabaseResult result;
    result.success = success;
    result.error = error;
    result.id = 0;
    return result;
}
DatabaseResult databaseFailure() {
    if (connection == 0) return makeResult(false, "Database is not connected.");
    if (sqlite3_extended_errcode(connection) == SQLITE_CONSTRAINT_UNIQUE)
        return makeResult(false, "A contact with that phone number already exists.");
    return makeResult(false, string("Database error: ") + sqlite3_errmsg(connection));
}
void closeDatabase() {
    if (connection != 0) {
        sqlite3_close(connection);
        connection = 0;
    }
}
DatabaseResult openDatabase(string path) {
    if (connection != 0) return makeResult(false, "A database is already connected.");
    if (path.empty() || path == ":memory:")
        return makeResult(false, "A persistent database file is required.");
    int status = sqlite3_open_v2(path.c_str(), &connection,
                              SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, 0);
    if (status != SQLITE_OK) {
        DatabaseResult result = databaseFailure();
        closeDatabase();
        return result;
    }
    sqlite3_busy_timeout(connection, 3000);
    sqlite3_exec(connection, "PRAGMA foreign_keys=ON", 0, 0, 0);
    // Single SQL statements are committed atomically by SQLite.
    const char* schema =
        "CREATE TABLE IF NOT EXISTS contacts ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT CHECK(id BETWEEN 1 AND 2147483647),"
        "name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 100),"
        "phone TEXT NOT NULL UNIQUE CHECK(length(phone) BETWEEN 7 AND 15 AND phone NOT GLOB '*[^0-9]*'),"
        "email TEXT NOT NULL DEFAULT '' CHECK(length(email)<=254),"
        "address TEXT NOT NULL DEFAULT '' CHECK(length(address)<=300))";
    status = sqlite3_exec(connection, schema, 0, 0, 0);
    if (status != SQLITE_OK) {
        DatabaseResult result = databaseFailure();
        closeDatabase();
        return result;
    }
    status = sqlite3_exec(connection, "CREATE TABLE IF NOT EXISTS contact_details(id INTEGER PRIMARY KEY REFERENCES contacts(id) ON DELETE CASCADE,payload TEXT NOT NULL)", 0, 0, 0);
    if (status != SQLITE_OK) { DatabaseResult result = databaseFailure(); closeDatabase(); return result; }
    DatabaseResult result = loadContacts();
    if (!result.success) closeDatabase();
    return result;
}
string columnText(sqlite3_stmt* statement, int column) {
    const unsigned char* text = sqlite3_column_text(statement, column);
    if (text == 0) return "";
    return string((const char*)text);
}
DatabaseResult loadContacts() {
    if (connection == 0) return databaseFailure();
    sqlite3_stmt* statement = 0;
    int status = sqlite3_prepare_v2(connection,
        "SELECT id,name,phone,email,address FROM contacts ORDER BY id", -1, &statement, 0);
    if (status != SQLITE_OK) {
        DatabaseResult result = databaseFailure();
        sqlite3_finalize(statement);
        return result;
    }
    DatabaseResult result = makeResult(true, "");
    status = sqlite3_step(statement);
    while (status == SQLITE_ROW) {
        Contact contact;
        contact.id = sqlite3_column_int64(statement, 0);
        contact.name = columnText(statement, 1);
        contact.phone = columnText(statement, 2);
        contact.email = columnText(statement, 3);
        contact.address = columnText(statement, 4);
        result.records.push_back(contact);
        status = sqlite3_step(statement);
    }
    if (status != SQLITE_DONE) result = databaseFailure();
    sqlite3_finalize(statement);
    return result;
}
// Values are bound separately from SQL to handle quotes safely.
bool bindFields(sqlite3_stmt* statement, Contact contact) {
    if (sqlite3_bind_text(statement, 1, contact.name.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) return false;
    if (sqlite3_bind_text(statement, 2, contact.phone.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) return false;
    if (sqlite3_bind_text(statement, 3, contact.email.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) return false;
    if (sqlite3_bind_text(statement, 4, contact.address.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) return false;
    return true;
}
DatabaseResult insertContact(Contact contact) {
    if (connection == 0) return databaseFailure();
    ContactCheck checked = checkContact(contact);
    if (!checked.valid) return makeResult(false, checked.error);
    sqlite3_stmt* statement = 0;
    int status = sqlite3_prepare_v2(connection,
        "INSERT INTO contacts(name,phone,email,address) VALUES(?,?,?,?)", -1, &statement, 0);
    if (status != SQLITE_OK || !bindFields(statement, checked.contact)) {
        DatabaseResult result = databaseFailure();
        sqlite3_finalize(statement);
        return result;
    }
    status = sqlite3_step(statement);
    DatabaseResult result = makeResult(true, "");
    if (status != SQLITE_DONE) result = databaseFailure();
    else result.id = sqlite3_last_insert_rowid(connection);
    sqlite3_finalize(statement);
    return result;
}
DatabaseResult updateStoredContact(Contact contact) {
    if (connection == 0) return databaseFailure();
    if (contact.id <= 0 || contact.id > 2147483647) return makeResult(false, "Invalid contact ID.");
    ContactCheck checked = checkContact(contact);
    if (!checked.valid) return makeResult(false, checked.error);
    sqlite3_stmt* statement = 0;
    int status = sqlite3_prepare_v2(connection,
        "UPDATE contacts SET name=?,phone=?,email=?,address=? WHERE id=?", -1, &statement, 0);
    if (status != SQLITE_OK || !bindFields(statement, checked.contact) ||
        sqlite3_bind_int64(statement, 5, contact.id) != SQLITE_OK) {
        DatabaseResult result = databaseFailure();
        sqlite3_finalize(statement);
        return result;
    }
    status = sqlite3_step(statement);
    DatabaseResult result = makeResult(true, "");
    if (status != SQLITE_DONE) result = databaseFailure();
    else if (sqlite3_changes(connection) == 0) result = makeResult(false, "No contact with that ID.");
    sqlite3_finalize(statement);
    return result;
}
DatabaseResult deleteStoredContact(long long id) {
    if (connection == 0) return databaseFailure();
    if (id <= 0 || id > 2147483647) return makeResult(false, "Invalid contact ID.");
    sqlite3_stmt* statement = 0;
    int status = sqlite3_prepare_v2(connection, "DELETE FROM contacts WHERE id=?", -1, &statement, 0);
    if (status != SQLITE_OK || sqlite3_bind_int64(statement, 1, id) != SQLITE_OK) {
        DatabaseResult result = databaseFailure();
        sqlite3_finalize(statement);
        return result;
    }
    status = sqlite3_step(statement);
    DatabaseResult result = makeResult(true, "");
    if (status != SQLITE_DONE) result = databaseFailure();
    else if (sqlite3_changes(connection) == 0) result = makeResult(false, "No contact with that ID.");
    sqlite3_finalize(statement);
    return result;
}

string loadContactDetails(long long id) {
    if (!connection) return "{}";
    sqlite3_stmt* statement = 0;
    if (sqlite3_prepare_v2(connection,"SELECT payload FROM contact_details WHERE id=?",-1,&statement,0)!=SQLITE_OK) return "{}";
    sqlite3_bind_int64(statement,1,id);
    string payload = sqlite3_step(statement)==SQLITE_ROW ? columnText(statement,0) : "{}";
    sqlite3_finalize(statement);
    return payload;
}
DatabaseResult saveContactDetails(long long id, string payload) {
    if (!connection) return databaseFailure();
    DatabaseResult loaded=loadContacts();
    if (!loaded.success) return loaded;
    if (findContactIndex(loaded.records,id)<0) return makeResult(false,"No contact with that ID.");
    if (payload.length()>10000) return makeResult(false,"Details are too long.");
    sqlite3_stmt* statement=0;
    int status=sqlite3_prepare_v2(connection,"INSERT INTO contact_details(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",-1,&statement,0);
    if(status!=SQLITE_OK) return databaseFailure();
    sqlite3_bind_int64(statement,1,id);
    sqlite3_bind_text(statement,2,payload.c_str(),-1,SQLITE_TRANSIENT);
    status=sqlite3_step(statement);sqlite3_finalize(statement);
    return status==SQLITE_DONE ? makeResult(true,"") : databaseFailure();
}
