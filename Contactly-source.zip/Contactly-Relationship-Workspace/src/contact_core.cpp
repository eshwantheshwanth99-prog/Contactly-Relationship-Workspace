#include "contact_core.hpp"

// Basic string traversal removes surrounding spaces and line endings.
string trimText(string text) {
    int first = 0;
    int last = (int)text.length() - 1;
    while (first <= last && (text[first] == ' ' || text[first] == '\t' || text[first] == '\r' || text[first] == '\n')) first++;
    while (last >= first && (text[last] == ' ' || text[last] == '\t' || text[last] == '\r' || text[last] == '\n')) last--;
    return text.substr(first, last - first + 1);
}
string lowercase(string text) {
    for (int i = 0; i < (int)text.length(); i++) {
        if (text[i] >= 'A' && text[i] <= 'Z') text[i] = text[i] + ('a' - 'A');
    }
    return text;
}
// An empty return value means that the phone is invalid.
string phoneDigits(string text) {
    text = trimText(text);
    string digits = "";
    for (int i = 0; i < (int)text.length(); i++) {
        char ch = text[i];
        if (ch >= '0' && ch <= '9') digits += ch;
        else if (ch == '+' && i == 0) { }
        else if (ch == ' ' || ch == '-' || ch == '(' || ch == ')') { }
        else return "";
    }
    if (digits.length() < 7 || digits.length() > 15) return "";
    return digits;
}
bool hasControlCharacter(string text) {
    for (int i = 0; i < (int)text.length(); i++) {
        if ((text[i] >= 0 && text[i] < 32) || text[i] == 127) return true;
    }
    return false;
}
bool validEmail(string text) {
    if (text.empty()) return true;
    int at = -1;
    for (int i = 0; i < (int)text.length(); i++) {
        if (text[i] == ' ') return false;
        if (text[i] == '@') {
            if (at != -1) return false;
            at = i;
        }
    }
    if (at <= 0 || at >= (int)text.length() - 1) return false;
    int dot = -1;
    for (int i = at + 1; i < (int)text.length(); i++) {
        if (text[i] == '.') { dot = i; break; }
    }
    return dot > at + 1 && dot < (int)text.length() - 1;
}
ContactCheck checkContact(Contact contact) {
    ContactCheck result;
    result.valid = false;
    result.error = "";
    contact.name = trimText(contact.name);
    contact.email = trimText(contact.email);
    contact.address = trimText(contact.address);
    contact.phone = phoneDigits(contact.phone);
    result.contact = contact;
    if (contact.name.empty() || contact.name.length() > 100)
        result.error = "Name must contain 1 to 100 bytes.";
    else if (hasControlCharacter(contact.name) || hasControlCharacter(contact.email) || hasControlCharacter(contact.address))
        result.error = "Text cannot contain control characters.";
    else if (contact.phone.empty())
        result.error = "Phone must have 7 to 15 digits; only a leading +, spaces, hyphens and parentheses are allowed.";
    else if (contact.email.length() > 254 || !validEmail(contact.email))
        result.error = "Enter an email like person@example.com, or leave it blank.";
    else if (contact.address.length() > 300)
        result.error = "Address cannot exceed 300 bytes.";
    else result.valid = true;
    return result;
}
int findContactIndex(vector<Contact> contacts, long long id) {
    for (int i = 0; i < (int)contacts.size(); i++) {
        if (contacts[i].id == id) return i;
    }
    return -1;
}
vector<Contact> searchNames(vector<Contact> contacts, string query) {
    vector<Contact> found;
    query = lowercase(trimText(query));
    if (query.empty()) return found;
    for (int i = 0; i < (int)contacts.size(); i++) {
        string name = lowercase(contacts[i].name);
        if (name.find(query) != string::npos) found.push_back(contacts[i]);
    }
    return found;
}
vector<Contact> searchPhones(vector<Contact> contacts, string phone) {
    vector<Contact> found;
    phone = phoneDigits(phone);
    if (phone.empty()) return found;
    for (int i = 0; i < (int)contacts.size(); i++) {
        if (contacts[i].phone == phone) found.push_back(contacts[i]);
    }
    return found;
}
vector<Contact> alphabeticalContacts(vector<Contact> contacts) {
    // Selection sort uses only nested loops, indexing and a temporary structure.
    for (int i = 0; i < (int)contacts.size(); i++) {
        int smallest = i;
        for (int j = i + 1; j < (int)contacts.size(); j++) {
            string candidate = lowercase(contacts[j].name);
            string current = lowercase(contacts[smallest].name);
            if (candidate < current || (candidate == current && contacts[j].id < contacts[smallest].id)) smallest = j;
        }
        Contact temporary = contacts[i];
        contacts[i] = contacts[smallest];
        contacts[smallest] = temporary;
    }
    return contacts;
}
