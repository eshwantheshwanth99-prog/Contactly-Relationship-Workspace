// Operations and database startup are handled by separate functions.
int runMenu();
int main() {
    return runMenu();
}
