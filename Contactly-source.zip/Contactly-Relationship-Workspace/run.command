#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
c++ -std=c++11 -Wall -Wextra -Wpedantic -Iinclude src/main.cpp src/menu.cpp src/contact_core.cpp src/database.cpp -lsqlite3 -o build/contact_manager
exec ./build/contact_manager
