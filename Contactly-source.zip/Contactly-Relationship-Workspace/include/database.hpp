#ifndef DATABASE_HPP
#define DATABASE_HPP
#include "contact_core.hpp"

// Ordinary structures carry success, errors and rows back to the menu.
// SQLite-specific pointer types are kept entirely inside database.cpp.
struct DatabaseResult {
    bool success;
    string error;
    long long id;
    vector<Contact> records;
};
DatabaseResult openDatabase(string path);
void closeDatabase();
DatabaseResult loadContacts();
DatabaseResult insertContact(Contact contact);
DatabaseResult updateStoredContact(Contact contact);
DatabaseResult deleteStoredContact(long long id);
string loadContactDetails(long long id);
DatabaseResult saveContactDetails(long long id, string payload);
#endif
