#ifndef CONTACT_CORE_HPP
#define CONTACT_CORE_HPP
#include <string>
#include <vector>
using namespace std;

struct Contact {
    long long id;
    string name;
    string phone;
    string email;
    string address;
};
struct ContactCheck {
    bool valid;
    string error;
    Contact contact;
};
string trimText(string text);
string lowercase(string text);
string phoneDigits(string text);
ContactCheck checkContact(Contact contact);
int findContactIndex(vector<Contact> contacts, long long id);
vector<Contact> searchNames(vector<Contact> contacts, string query);
vector<Contact> searchPhones(vector<Contact> contacts, string phone);
vector<Contact> alphabeticalContacts(vector<Contact> contacts);
#endif
